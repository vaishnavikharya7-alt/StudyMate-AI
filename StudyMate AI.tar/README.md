# 🎓 StudyMate AI — Your Personal AI Learning Companion

> **Learn Smarter. Build Faster. Achieve More.**

StudyMate AI is a premium, production-ready AI student productivity platform: a ChatGPT-style study assistant, notes & quiz generators, a smart study planner, an assignment helper, a code assistant and a full analytics dashboard — wrapped in a clean white SaaS interface with soft blue/purple accents.

`AI Powered` · `Student Friendly` · `Smart Learning`

---

## ✨ Features

| Module | What it does |
| --- | --- |
| **Dashboard** | Welcome hero, profile summary, daily study goal, study streak, completed tasks, focus timer (logs real study minutes), quick AI tool access, recent activities feed, today's timetable |
| **AI Chat** | ChatGPT-style tutor with markdown answers, code blocks with copy buttons, typing indicator, chat history, clear chat, Enter-to-send, retry on errors |
| **Notes Generator** | Any subject/topic × difficulty × short/detailed → structured notes (definitions, explanations, examples, key points, exam questions). Copy, download as **TXT**, save to library |
| **Quiz Generator** | MCQs (3/5/10/15 questions, easy/medium/hard) with instant answer feedback, explanations, score %, performance report, answer review, results saved to Progress |
| **Study Planner** | Subject manager, tasks with deadlines/priority/estimates, filters (All/Today/Upcoming/Completed), overdue alerts, daily goal slider, quick study-time logging |
| **Assignment Helper** | Step-by-step structured solutions: understanding → key concepts → worked solution → model answer → tips |
| **Code Assistant** | **Python · C · C++ · Java · JavaScript** — explain, debug (paste errors!), generate, improve. Formatted code blocks with copy |
| **Progress Tracker** | 7-day study-time bar chart, quiz trend area chart, subject-wise donut + progress bars, streaks, completed assignments, quiz history |
| **Extras** | Global search (Ctrl/Cmd + K), dark/light/system theme, toast notifications, empty states, loading skeletons, form validation, JSON backup export, mobile drawer navigation, sticky footer |

---

## 🧱 Technology Stack

| Layer | Choice |
| --- | --- |
| Framework | **Next.js 16 (App Router)** + **TypeScript 5** |
| Styling | **Tailwind CSS 4** + shadcn/ui (New York) |
| Icons / Motion | lucide-react + framer-motion |
| Charts | recharts |
| State | **zustand** with `persist` middleware → **LocalStorage** (profile, tasks, sessions, streaks, quiz results, notes, chat history, theme) |
| Markdown | react-markdown + remark-gfm |
| AI Backend | **z-ai-web-dev-sdk via Next.js API routes** — the SDK and its credentials run **server-side only**, so no API key is ever exposed to the browser |

> Note: this project ships as a Next.js application (single `/` route, SPA-style view switching) rather than separate `index.html/style.css/script.js` files. All the requested vanilla-JS behaviours (LocalStorage progress, working nav links, validated forms, theme persistence) are implemented with the same zero-backend-storage philosophy, plus a genuinely secure AI backend.

---

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx                  # App shell: sidebar + topbar + animated view switching
│   ├── layout.tsx                # Metadata, fonts, ThemeProvider, Toaster
│   ├── globals.css               # Design tokens (light/dark), brand gradients, scrollbars
│   └── api/                      # 🔒 Secure AI backend (server-only)
│       ├── chat/route.ts         # POST — study tutor chat completions
│       ├── notes/route.ts        # POST — structured notes generator
│       ├── quiz/route.ts         # POST — MCQ JSON generator (+ validation & retry)
│       ├── assignment/route.ts   # POST — step-by-step assignment help
│       └── code/route.ts         # POST — explain/debug/generate/improve code
├── components/
│   ├── studymate/
│   │   ├── sidebar.tsx           # Responsive sidebar (desktop fixed, mobile Sheet)
│   │   ├── topbar.tsx            # Search (Ctrl+K), theme toggle, profile menu
│   │   ├── nav-config.tsx        # Single source of truth for navigation
│   │   ├── markdown-view.tsx     # Shared markdown renderer + copy-able code blocks
│   │   └── views/
│   │       ├── dashboard.tsx     ├── progress.tsx
│   │       ├── chat.tsx          ├── notes.tsx
│   │       ├── quiz.tsx          ├── planner.tsx
│   │       ├── assignment.tsx    ├── code-assistant.tsx
│   │       └── settings.tsx
│   └── ui/                       # shadcn/ui component library
├── lib/studymate/
│   ├── store.ts                  # zustand store (LocalStorage persistence)
│   ├── types.ts                  # Shared TypeScript types
│   ├── api-client.ts             # Frontend fetch wrapper for /api/*
│   ├── ai.ts                     # Server-side SDK helper (errors, JSON parsing)
│   └── helpers.ts                # Dates, streaks, formatting, clipboard, colors
└── hooks/
    └── use-hydrated.ts           # SSR-safe hydration hooks
```

---

## 🚀 Run Locally

```bash
# 1. Install dependencies
bun install        # or: npm install / pnpm install

# 2. Start the dev server
bun run dev        # http://localhost:3000

# 3. Quality checks
bun run lint       # ESLint
bunx tsc --noEmit  # TypeScript
```

Open **http://localhost:3000** — you'll land on the Dashboard. Set your name in **Settings → Student profile** to personalise the experience.

---

## 🔐 AI Backend Configuration

- All AI features call internal endpoints (`/api/chat`, `/api/notes`, `/api/quiz`, `/api/assignment`, `/api/code`) — **never any third-party API directly from the browser**.
- The SDK credentials are provided by the runtime environment (`z-ai-web-dev-sdk` reads its configuration server-side). There is **no key in any frontend file**.
- If the AI service is unavailable, every UI shows a clear, friendly error (with retry) instead of fake responses.
- **Bring your own keys (custom deployment):** in any Node environment, set the SDK's environment variables (e.g. `ZAI_API_KEY`, `ZAI_BASE_URL` — see the SDK docs) in your `.env` before starting the server. Example:

```bash
# .env (server-side only — never commit)
ZAI_API_KEY=your-key-here
ZAI_BASE_URL=https://api.example.com
```

---

## 🌍 Deployment

**Vercel (recommended)**
1. Push this repo to GitHub/GitLab.
2. Import it at [vercel.com/new](https://vercel.com/new) — the Next.js app is auto-detected.
3. Add the AI environment variables in *Project → Settings → Environment Variables*.
4. Deploy. Done.

**Self-hosted / VPS**
```bash
bun run build
bun run start        # serves the production build (see package.json)
```
Put it behind Nginx/Caddy for TLS. The app is a standard Node server, so it also works in Docker.

---

## 💾 Data & Privacy

- 100% of user progress (profile, tasks, sessions, streaks, quiz scores, notes, chats) lives in **LocalStorage** on the student's device — no tracking, no accounts required.
- **Settings → Your data** offers a one-click **JSON backup export** and a guarded **Reset all data** action.

---

## 🎨 Branding

- **Name:** StudyMate AI
- **Tagline:** Learn Smarter. Build Faster. Achieve More.
- **Positioning:** Your Personal AI Learning Companion
- **Palette:** white canvas, soft blue (`#3b82f6`) → violet (`#8b5cf6`) gradient accents, rounded-2xl cards, subtle shadows
- **Badges:** AI Powered · Student Friendly · Smart Learning

---

Built with ❤️ for students. Start with the Dashboard, plan your day in the Planner, then let the AI tools do the heavy lifting.
