/**
 * StudyMate AI — Shared type definitions
 * Used by the zustand store, API client, API routes and all view components.
 */

export type ViewKey =
  | 'dashboard'
  | 'chat'
  | 'notes'
  | 'quiz'
  | 'planner'
  | 'assignment'
  | 'code'
  | 'progress'
  | 'settings';

export type Priority = 'low' | 'medium' | 'high';

export interface StudyTask {
  id: string;
  title: string;
  subject: string;
  /** Local date key, format yyyy-mm-dd */
  deadline: string;
  priority: Priority;
  estimatedMinutes: number;
  completed: boolean;
  createdAt: string;
  completedAt?: string;
}

export interface StudySession {
  id: string;
  /** Local date key, format yyyy-mm-dd */
  date: string;
  minutes: number;
  subject?: string;
  note?: string;
  at: string;
}

export type ActivityType =
  | 'task'
  | 'quiz'
  | 'notes'
  | 'chat'
  | 'assignment'
  | 'code'
  | 'session'
  | 'plan';

export interface ActivityItem {
  id: string;
  type: ActivityType;
  title: string;
  detail?: string;
  at: string;
}

export interface QuizResult {
  id: string;
  subject: string;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  score: number;
  total: number;
  at: string;
}

export interface ChatMsg {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  at: string;
}

export interface NoteDoc {
  id: string;
  subject: string;
  topic: string;
  difficulty: string;
  style: 'short' | 'detailed';
  content: string;
  at: string;
}

export interface Profile {
  name: string;
  grade: string;
  school: string;
  targetExam: string;
  favoriteSubjects: string;
  /** Minutes per day, 15 - 480 */
  dailyGoalMinutes: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface FocusTimer {
  /** Epoch ms when the timer was started, null when idle */
  startedAt: number | null;
  /** Seconds accumulated across runs */
  accumulatedSec: number;
}

/** ---------- AI API payloads ---------- */

export interface ChatMessagePayload {
  role: 'user' | 'assistant';
  content: string;
}

export interface NotesInput {
  subject: string;
  topic: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  style: 'short' | 'detailed';
}

export interface QuizInput {
  subject: string;
  topic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  count: number;
}

export interface AssignmentInput {
  subject: string;
  question: string;
}

export type CodeMode = 'explain' | 'debug' | 'generate' | 'improve';

export interface CodeInput {
  language: 'python' | 'c' | 'cpp' | 'java' | 'javascript';
  mode: CodeMode;
  code?: string;
  question?: string;
}
