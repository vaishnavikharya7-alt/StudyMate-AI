/**
 * POST /api/code — programming assistant for Python, C, C++, Java and JavaScript.
 * Modes: explain | debug | generate | improve
 */
import { NextRequest, NextResponse } from 'next/server';
import { complete, friendlyAIError } from '@/lib/studymate/ai';
import type { CodeMode } from '@/lib/studymate/types';

export const dynamic = 'force-dynamic';

const LANGUAGES: Record<string, string> = {
  python: 'Python 3',
  c: 'C (C99)',
  cpp: 'C++ (C++17)',
  java: 'Java (17)',
  javascript: 'JavaScript (ES2023)',
};

function buildPrompt(
  language: string,
  mode: CodeMode,
  code: string,
  question: string,
) {
  const lang = LANGUAGES[language] ?? language;

  const heads: Record<CodeMode, string> = {
    explain: `Explain what the following ${lang} code does.
Structure the answer in Markdown:
## What the Code Does — 1-2 sentence summary.
## Step-by-Step Walkthrough — walk through the logic block by block.
## Key Concepts Used — bullet list of the programming concepts involved.
## Potential Issues — anything fragile (edge cases, complexity) worth knowing.`,
    debug: `Debug the following ${lang} code${question ? `. The user reports: "${question}"` : ''}.
Find the bug(s) and explain the fix.
Structure the answer in Markdown:
## What's Wrong — each bug with a short explanation of why it fails.
## Fixed Code — the complete corrected code in a single fenced code block tagged with the right language.
## Explanation of the Fix — why the fix works.
## How to Avoid This — 2-3 practical tips.
If the user pasted an error message, first explain in plain words what it means.`,
    generate: `Write a clean, well-commented ${lang} program based on this request:
"${question}"
Structure the answer in Markdown:
## Approach — how you will solve it.
## Code — complete, runnable, commented code in ONE fenced code block tagged with the right language.
## How It Works — brief walkthrough of the important parts.
## Sample Output — example run (as a plain code block).
Keep the code simple and idiomatic; avoid advanced features a student would not know.`,
    improve: `Review and improve the following ${lang} code.
Structure the answer in Markdown:
## Overall Assessment — short verdict on readability, correctness and efficiency.
## Suggested Improvements — prioritized, concrete list (naming, structure, performance, edge cases).
## Improved Code — the refactored version in ONE fenced code block tagged with the right language.
## Summary of Changes — bullet list mapping each change to its reason.`,
  };

  const codeBlock = code
    ? `Code:\n\`\`\`${language}\n${code.slice(0, 8000)}\n\`\`\`\n\n`
    : '';
  return `${heads[mode]}\n\n${codeBlock}${mode === 'generate' ? '' : question ? `Additional note from the user: ${question}\n` : ''}`.trim();
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const language = String(body?.language ?? '');
    const mode = String(body?.mode ?? '') as CodeMode;
    const code = typeof body?.code === 'string' ? body.code : '';
    const question = typeof body?.question === 'string' ? body.question.trim() : '';

    if (!LANGUAGES[language]) {
      return NextResponse.json(
        { error: 'Unsupported language. Choose Python, C, C++, Java or JavaScript.' },
        { status: 400 },
      );
    }
    if (!['explain', 'debug', 'generate', 'improve'].includes(mode)) {
      return NextResponse.json({ error: 'Invalid mode.' }, { status: 400 });
    }
    if (mode === 'generate' && question.length < 5) {
      return NextResponse.json(
        { error: 'Describe what code you want to generate (at least 5 characters).' },
        { status: 400 },
      );
    }
    if (mode !== 'generate' && code.trim().length === 0) {
      return NextResponse.json(
        { error: 'Paste your code in the editor first.' },
        { status: 400 },
      );
    }

    const system = `You are StudyMate AI's Code Assistant — a patient, expert programming teacher for ${LANGUAGES[language]}.
Always put code in fenced code blocks with the correct language tag.
Explain like a mentor helping a student learn, pointing out the "why" behind every important line.`;

    const content = await complete([
      { role: 'assistant', content: system },
      { role: 'user', content: buildPrompt(language, mode, code, question) },
    ]);

    return NextResponse.json({ content });
  } catch (err) {
    console.error('[api/code]', err);
    return NextResponse.json({ error: friendlyAIError(err) }, { status: 502 });
  }
}
