/**
 * POST /api/notes — generate structured study notes.
 * Returns markdown content with definitions, explanations, examples and key points.
 */
import { NextRequest, NextResponse } from 'next/server';
import { complete, friendlyAIError } from '@/lib/studymate/ai';

export const dynamic = 'force-dynamic';

function buildPrompt(subject: string, topic: string, difficulty: string, style: string) {
  const depth =
    style === 'detailed'
      ? `Create DETAILED, exam-ready study notes (roughly 600-900 words).`
      : `Create SHORT, crisp revision notes (roughly 250-400 words).`;

  return `${depth}

Subject: ${subject}
Topic: ${topic}
Difficulty level: ${difficulty}

Write the notes in Markdown with exactly these sections (use ## headings):
## Overview — 2-3 sentence introduction to the topic.
## Important Definitions — every key term with a clear, student-friendly definition (use a bullet or numbered list; use a markdown table if there are many terms).
## Explanation${style === 'detailed' ? ' (Detailed)' : ''} — the core concepts explained step by step${style === 'detailed' ? ', covering sub-topics and the "why" behind each idea' : ''}.
## Examples — at least 2 worked examples or real-life applications.
## Key Points to Remember — a bulleted list of the most important takeaways.
## Possible Exam Questions — 3-5 questions students should practice${style === 'detailed' ? ', with brief answer hints' : ''}.

Rules:
- Content must be factually accurate and appropriate for the "${difficulty}" level.
- Use **bold** for key terms. Use tables where they genuinely help.
- Do not mention that you are an AI. Do not add any preamble before the "## Overview" heading.`;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const subject = String(body?.subject ?? '').trim().slice(0, 80);
    const topic = String(body?.topic ?? '').trim().slice(0, 120);
    const difficulty = ['beginner', 'intermediate', 'advanced'].includes(
      String(body?.difficulty),
    )
      ? String(body?.difficulty)
      : 'intermediate';
    const style = String(body?.style) === 'detailed' ? 'detailed' : 'short';

    if (!subject || !topic) {
      return NextResponse.json(
        { error: 'Subject and topic are both required.' },
        { status: 400 },
      );
    }

    const content = await complete([
      {
        role: 'assistant',
        content:
          'You are an expert academic tutor who writes well-structured, accurate study notes in clean Markdown. You always follow the requested structure exactly.',
      },
      { role: 'user', content: buildPrompt(subject, topic, difficulty, style) },
    ]);

    return NextResponse.json({ content });
  } catch (err) {
    console.error('[api/notes]', err);
    return NextResponse.json({ error: friendlyAIError(err) }, { status: 502 });
  }
}
