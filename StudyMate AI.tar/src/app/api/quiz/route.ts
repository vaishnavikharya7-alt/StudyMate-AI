/**
 * POST /api/quiz — generate multiple-choice questions as strict JSON.
 * The AI must return a JSON array; we parse defensively and validate every item.
 */
import { NextRequest, NextResponse } from 'next/server';
import { complete, friendlyAIError, parseJsonFromAI } from '@/lib/studymate/ai';
import type { QuizQuestion } from '@/lib/studymate/types';

export const dynamic = 'force-dynamic';

function buildPrompt(subject: string, topic: string, difficulty: string, count: number) {
  return `Generate exactly ${count} multiple-choice quiz questions.

Subject: ${subject}
Topic: ${topic}
Difficulty: ${difficulty}

Return STRICT JSON only — no markdown fences, no commentary. Schema:
[
  {
    "question": "clear question text",
    "options": ["option A", "option B", "option C", "option D"],
    "correctIndex": 0,
    "explanation": "1-3 sentences explaining why the correct answer is right and, briefly, why common wrong options are wrong"
  }
]

Rules:
- Exactly 4 options per question; exactly one correct answer.
- "correctIndex" is 0-based (0..3) and must point to a genuinely correct option.
- Randomize which position holds the correct answer across questions.
- Explanations must teach — do not just restate the answer.
- Questions must be appropriate for ${difficulty} difficulty and specific to the topic "${topic}" in ${subject}.
- Output must start with [ and end with ].`;
}

interface RawQuestion {
  question?: unknown;
  options?: unknown;
  correctIndex?: unknown;
  explanation?: unknown;
}

function validateQuestions(data: unknown, count: number): QuizQuestion[] {
  const arr = Array.isArray(data) ? data : null;
  if (!arr) throw new Error('AI_JSON_PARSE_FAILED');

  const valid: QuizQuestion[] = [];
  for (const item of arr) {
    const q = item as RawQuestion;
    const options = Array.isArray(q.options)
      ? q.options.map((o) => String(o).trim()).filter(Boolean)
      : [];
    const idx = Number(q.correctIndex);
    if (
      typeof q.question === 'string' &&
      q.question.trim().length > 0 &&
      options.length === 4 &&
      Number.isInteger(idx) &&
      idx >= 0 &&
      idx < 4 &&
      typeof q.explanation === 'string' &&
      q.explanation.trim().length > 0
    ) {
      valid.push({
        id: `${valid.length}`,
        question: q.question.trim(),
        options,
        correctIndex: idx,
        explanation: q.explanation.trim(),
      });
    }
  }
  if (valid.length === 0) throw new Error('AI_JSON_PARSE_FAILED');
  return valid.slice(0, count);
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const subject = String(body?.subject ?? '').trim().slice(0, 80);
    const topic = String(body?.topic ?? '').trim().slice(0, 120);
    const difficulty = ['easy', 'medium', 'hard'].includes(String(body?.difficulty))
      ? String(body?.difficulty)
      : 'medium';
    const requested = Number(body?.count);
    const count = [3, 5, 10, 15].includes(requested) ? requested : 5;

    if (!subject || !topic) {
      return NextResponse.json(
        { error: 'Subject and topic are both required.' },
        { status: 400 },
      );
    }

    const system =
      'You are an expert exam setter. You output ONLY valid JSON matching the requested schema, with no extra text.';

    let questions: QuizQuestion[];
    try {
      const raw = await complete([
        { role: 'assistant', content: system },
        { role: 'user', content: buildPrompt(subject, topic, difficulty, count) },
      ]);
      questions = validateQuestions(parseJsonFromAI(raw), count);
    } catch (err) {
      const raw = err instanceof Error ? err.message : String(err);
      if (raw === 'AI_JSON_PARSE_FAILED') {
        // One retry with an even stricter instruction.
        const retry = await complete([
          { role: 'assistant', content: system },
          {
            role: 'user',
            content: `${buildPrompt(subject, topic, difficulty, count)}\n\nIMPORTANT: Your previous output was not parseable JSON. Output pure JSON only — the very first character must be "[" and the very last must be "]".`,
          },
        ]);
        questions = validateQuestions(parseJsonFromAI(retry), count);
      } else {
        throw err;
      }
    }

    return NextResponse.json({ questions });
  } catch (err) {
    console.error('[api/quiz]', err);
    const raw = err instanceof Error ? err.message : String(err);
    const message =
      raw === 'AI_JSON_PARSE_FAILED'
        ? 'The AI returned a malformed quiz. Please try generating again.'
        : friendlyAIError(err);
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
