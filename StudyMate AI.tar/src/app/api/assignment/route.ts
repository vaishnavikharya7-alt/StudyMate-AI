/**
 * POST /api/assignment — step-by-step assignment help.
 * Produces a structured, educational answer (never just a final answer).
 */
import { NextRequest, NextResponse } from 'next/server';
import { complete, friendlyAIError } from '@/lib/studymate/ai';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const subject = String(body?.subject ?? '').trim().slice(0, 80) || 'General';
    const question = String(body?.question ?? '').trim().slice(0, 4000);

    if (question.length < 10) {
      return NextResponse.json(
        { error: 'Please enter the assignment question (at least 10 characters).' },
        { status: 400 },
      );
    }

    const system = `You are StudyMate AI's Assignment Helper, an expert ${subject} tutor.
Your goal is to help the student truly understand the problem — teach, do not just answer.`;

    const prompt = `Assignment subject: ${subject}

Assignment question / task:
"""
${question}
"""

Produce a Markdown response with exactly these sections (## headings):
## Understanding the Question — restate what is being asked in simple words and list what the grader expects.
## Key Concepts Needed — the concepts/formulas/rules required, each with a one-line explanation.
## Step-by-Step Solution — numbered steps; show all working for calculations and full reasoning for theory. End with the final answer clearly marked in **bold**.
## Final Structured Answer — a clean, submission-ready model answer for this question.
## Examples & Tips — one similar practice example plus 2-3 tips to avoid common mistakes in this type of question.

Rules:
- Be accurate and appropriate for a student's level.
- Use **bold** for key results and terms; use LaTeX-style notation sparingly as plain text (e.g., a^2 + b^2 = c^2) — the UI renders Markdown, not LaTeX.
- If the question is ambiguous, state your assumption in "Understanding the Question" and proceed.
- Do not mention that you are an AI.`;

    const content = await complete([
      { role: 'assistant', content: system },
      { role: 'user', content: prompt },
    ]);

    return NextResponse.json({ content });
  } catch (err) {
    console.error('[api/assignment]', err);
    return NextResponse.json({ error: friendlyAIError(err) }, { status: 502 });
  }
}
