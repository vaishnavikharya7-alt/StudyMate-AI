/**
 * POST /api/chat — secure AI chat endpoint for StudyMate AI.
 * Receives the conversation history from the client and returns the assistant reply.
 * The AI SDK and its credentials live entirely on the server.
 */
import { NextRequest, NextResponse } from 'next/server';
import { complete, friendlyAIError } from '@/lib/studymate/ai';
import type { ChatMessagePayload } from '@/lib/studymate/types';

export const dynamic = 'force-dynamic';

const SYSTEM_PROMPT = `You are StudyMate AI, a friendly, encouraging and knowledgeable study companion for students.

Guidelines:
- Explain concepts clearly and simply, adjusting depth to the student's question.
- Use Markdown formatting: short paragraphs, bullet lists, **bold** for key terms, and tables when helpful.
- Use fenced code blocks with a language tag for any code.
- When solving problems, show clear step-by-step reasoning.
- Be concise but complete; avoid unnecessary padding.
- End longer answers with a short "Quick recap" or a follow-up suggestion when useful.
- Encourage healthy study habits; you are a tutor, not a homework-doing machine — but always help.`;

const MAX_HISTORY = 30;

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { messages?: unknown };
    const raw = Array.isArray(body?.messages) ? body.messages : null;

    if (!raw) {
      return NextResponse.json(
        { error: 'Invalid request: "messages" array is required.' },
        { status: 400 },
      );
    }

    // Sanitize and cap the history we forward.
    const messages: ChatMessagePayload[] = raw
      .filter(
        (m): m is ChatMessagePayload =>
          !!m &&
          typeof m === 'object' &&
          ((m as ChatMessagePayload).role === 'user' ||
            (m as ChatMessagePayload).role === 'assistant') &&
          typeof (m as ChatMessagePayload).content === 'string' &&
          (m as ChatMessagePayload).content.trim().length > 0,
      )
      .slice(-MAX_HISTORY)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 8000) }));

    if (messages.length === 0 || messages[messages.length - 1].role !== 'user') {
      return NextResponse.json(
        { error: 'Invalid request: the last message must come from the user.' },
        { status: 400 },
      );
    }

    const content = await complete([
      { role: 'assistant', content: SYSTEM_PROMPT },
      ...messages,
    ]);

    return NextResponse.json({ content });
  } catch (err) {
    console.error('[api/chat]', err);
    return NextResponse.json({ error: friendlyAIError(err) }, { status: 502 });
  }
}
