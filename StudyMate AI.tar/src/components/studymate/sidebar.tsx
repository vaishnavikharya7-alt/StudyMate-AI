'use client';

/**
 * StudyMate AI — responsive sidebar.
 * Fixed on desktop (lg+), slide-in Sheet on mobile.
 */
import { GraduationCap, Flame, Sparkles } from 'lucide-react';
import { currentStreak, activeDatesFrom } from '@/lib/studymate/helpers';
import { useAppStore } from '@/lib/studymate/store';
import { cn } from '@/lib/utils';
import { NAV_GROUPS } from './nav-config';
import type { ViewKey } from '@/lib/studymate/types';
import { Badge } from '@/components/ui/badge';

function SidebarContent({ onNavigate }: { onNavigate: (v: ViewKey) => void }) {
  const view = useAppStore((s) => s.view);
  const tasks = useAppStore((s) => s.tasks);
  const sessions = useAppStore((s) => s.sessions);
  const quizResults = useAppStore((s) => s.quizResults);
  const streak = currentStreak(activeDatesFrom({ sessions, tasks, quizResults }));

  return (
    <div className="flex h-full flex-col">
      {/* Brand */}
      <button
        type="button"
        onClick={() => onNavigate('dashboard')}
        className="flex items-center gap-3 px-5 pt-6 pb-5 text-left"
        aria-label="StudyMate AI home"
      >
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-gradient shadow-md shadow-blue-500/20">
          <GraduationCap className="h-6 w-6 text-white" />
        </span>
        <span>
          <span className="block text-[17px] font-bold leading-tight tracking-tight">
            StudyMate <span className="text-gradient">AI</span>
          </span>
          <span className="block text-[11px] text-muted-foreground">
            Your AI Learning Companion
          </span>
        </span>
      </button>

      {/* Nav */}
      <nav className="scrollbar-thin flex-1 space-y-5 overflow-y-auto px-3 pb-4" aria-label="Main navigation">
        {NAV_GROUPS.map((group) => (
          <div key={group.title}>
            <p className="mb-1.5 px-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">
              {group.title}
            </p>
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const active = view === item.key;
                const Icon = item.icon;
                return (
                  <li key={item.key}>
                    <button
                      type="button"
                      onClick={() => onNavigate(item.key)}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        'group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all',
                        active
                          ? 'bg-brand-gradient text-white shadow-md shadow-blue-500/20'
                          : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
                      )}
                    >
                      <Icon
                        className={cn(
                          'h-[18px] w-[18px] shrink-0 transition-transform group-hover:scale-110',
                          active ? 'text-white' : 'text-muted-foreground/80',
                        )}
                      />
                      {item.label}
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Streak card */}
      <div className="mx-3 mb-4 rounded-2xl border bg-card p-4 shadow-sm">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-100 dark:bg-orange-500/15">
            <Flame className="h-4.5 w-4.5 text-orange-500" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold leading-tight">
              {streak} day{streak === 1 ? '' : 's'} streak
            </p>
            <p className="truncate text-[11px] text-muted-foreground">
              {streak > 0 ? 'Keep the momentum going!' : 'Study today to start one'}
            </p>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-1.5">
          <Badge variant="secondary" className="gap-1 text-[10px]">
            <Sparkles className="h-3 w-3 text-purple-500" /> AI Powered
          </Badge>
          <Badge variant="secondary" className="text-[10px]">
            Smart Learning
          </Badge>
        </div>
      </div>
    </div>
  );
}

export function Sidebar({ onNavigate }: { onNavigate: (v: ViewKey) => void }) {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r bg-sidebar text-sidebar-foreground lg:block">
      <SidebarContent onNavigate={onNavigate} />
    </aside>
  );
}

export { SidebarContent };
