'use client';

/**
 * StudyMate AI — Progress Tracker view
 * Study analytics: overview stats, weekly bar chart, quiz trend,
 * subject-wise breakdown, completed assignments and quiz history.
 */

import { useMemo } from 'react';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  CalendarDays,
  CheckCircle2,
  Clock,
  Flame,
  GraduationCap,
  ListChecks,
  type LucideIcon,
} from 'lucide-react';

import { useAppStore } from '@/lib/studymate/store';
import {
  activeDatesFrom,
  currentStreak,
  formatMinutes,
  formatRelative,
  lastNDayKeys,
  minutesOnDate,
  subjectColor,
} from '@/lib/studymate/helpers';
import type { QuizResult, ViewKey } from '@/lib/studymate/types';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

/* ---------- motion helper ---------- */

const rise = (delay: number) => ({
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.35, ease: 'easeOut' as const, delay },
});

/* ---------- design tokens ---------- */

const TINTS = {
  blue: 'bg-blue-50 text-blue-600 dark:bg-blue-500/10 dark:text-blue-400',
  purple: 'bg-purple-50 text-purple-600 dark:bg-purple-500/10 dark:text-purple-400',
  emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-400',
  cyan: 'bg-cyan-50 text-cyan-600 dark:bg-cyan-500/10 dark:text-cyan-400',
} as const;

const DIFFICULTY_TINT: Record<QuizResult['difficulty'], string> = {
  easy: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-400',
  medium: 'bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
  hard: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-400',
};

/* Shared tooltip styling that adapts to light/dark via semantic CSS variables. */
const TOOLTIP_PROPS = {
  contentStyle: {
    backgroundColor: 'var(--card)',
    border: '1px solid var(--border)',
    borderRadius: '12px',
    fontSize: '12px',
    color: 'var(--card-foreground)',
    boxShadow: '0 8px 24px rgb(15 23 42 / 0.10)',
  },
  labelStyle: { color: 'var(--muted-foreground)', marginBottom: '2px' },
  itemStyle: { color: 'var(--card-foreground)' },
} as const;

/* ---------- small building blocks ---------- */

function StatCard({
  label,
  icon: Icon,
  tint,
  value,
  sub,
}: {
  label: string;
  icon: LucideIcon;
  tint: string;
  value: string;
  sub: string;
}) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">{label}</p>
        <span className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-xl', tint)}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <p className="mt-3 text-2xl font-bold tracking-tight tabular-nums">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

function CardHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <>
      <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
      <p className="text-sm text-muted-foreground">{subtitle}</p>
    </>
  );
}

/* ---------- view ---------- */

export default function ProgressView({ onNavigate }: { onNavigate: (v: ViewKey) => void }) {
  const tasks = useAppStore((s) => s.tasks);
  const sessions = useAppStore((s) => s.sessions);
  const quizResults = useAppStore((s) => s.quizResults);

  /* ----- overview stats ----- */
  const totalMinutes = useMemo(() => sessions.reduce((sum, s) => sum + s.minutes, 0), [sessions]);
  const weekMinutes = useMemo(
    () => lastNDayKeys(7).reduce((sum, k) => sum + minutesOnDate(sessions, k), 0),
    [sessions],
  );
  const quizAvg = useMemo(() => {
    if (quizResults.length === 0) return null;
    return Math.round(
      quizResults.reduce((sum, q) => sum + (q.score / q.total) * 100, 0) / quizResults.length,
    );
  }, [quizResults]);
  const tasksDone = tasks.filter((t) => t.completed).length;
  const tasksPct = tasks.length > 0 ? Math.round((tasksDone / tasks.length) * 100) : 0;

  const streak = useMemo(
    () => currentStreak(activeDatesFrom({ sessions, tasks, quizResults })),
    [sessions, tasks, quizResults],
  );

  /* ----- chart data ----- */
  const weeklyBar = useMemo(
    () =>
      lastNDayKeys(7).map((k) => ({
        day: format(new Date(`${k}T00:00:00`), 'EEE'),
        minutes: minutesOnDate(sessions, k),
      })),
    [sessions],
  );

  const quizTrend = useMemo(
    () =>
      quizResults
        .slice(0, 10)
        .reverse()
        .map((q, i) => ({ name: `#${i + 1}`, pct: Math.round((q.score / q.total) * 100) })),
    [quizResults],
  );

  /* ----- subject-wise breakdown ----- */
  const subjectMinutes = useMemo(() => {
    const map = new Map<string, number>();
    sessions.forEach((s) => {
      const key = s.subject?.trim() || 'Other';
      map.set(key, (map.get(key) ?? 0) + s.minutes);
    });
    return Array.from(map.entries())
      .map(([name, minutes]) => ({ name, minutes, color: subjectColor(name) }))
      .sort((a, b) => b.minutes - a.minutes);
  }, [sessions]);
  const maxSubjectMinutes = subjectMinutes.length > 0 ? subjectMinutes[0].minutes : 0;
  const pieData = useMemo(() => subjectMinutes.slice(0, 6), [subjectMinutes]);

  /* ----- bottom lists ----- */
  const completedTasks = useMemo(
    () =>
      tasks
        .filter((t) => t.completed)
        .sort((a, b) => (b.completedAt ?? b.createdAt).localeCompare(a.completedAt ?? a.createdAt))
        .slice(0, 8),
    [tasks],
  );
  const quizHistory = useMemo(() => quizResults.slice(0, 8), [quizResults]);

  return (
    <div className="space-y-6">
      {/* ----- header ----- */}
      <motion.header {...rise(0)} className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Progress Tracker</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your study analytics at a glance.</p>
        </div>
        {streak > 0 ? (
          <span className="inline-flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-xs font-medium shadow-sm">
            <Flame className="h-4 w-4 text-orange-500" />
            {streak} {streak === 1 ? 'day' : 'days'} streak
          </span>
        ) : null}
      </motion.header>

      {/* ----- overview stats ----- */}
      <motion.section {...rise(0.05)} aria-label="Overview stats">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard
            label="Total study time"
            icon={Clock}
            tint={TINTS.blue}
            value={formatMinutes(totalMinutes)}
            sub="Across all sessions"
          />
          <StatCard
            label="This week"
            icon={CalendarDays}
            tint={TINTS.cyan}
            value={formatMinutes(weekMinutes)}
            sub="Minutes in the last 7 days"
          />
          <StatCard
            label="Avg quiz score"
            icon={GraduationCap}
            tint={TINTS.purple}
            value={quizAvg === null ? '—' : `${quizAvg}%`}
            sub={quizAvg === null ? 'No quizzes yet' : 'Across all quizzes'}
          />
          <StatCard
            label="Tasks done"
            icon={CheckCircle2}
            tint={TINTS.emerald}
            value={`${tasksDone}/${tasks.length}`}
            sub={tasks.length > 0 ? `${tasksPct}% of all tasks` : 'No tasks yet'}
          />
        </div>
      </motion.section>

      {/* ----- charts ----- */}
      <motion.section {...rise(0.1)} className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <CardHeader
            title="Study time — last 7 days"
            subtitle="Minutes studied per day this week."
          />
          {sessions.length === 0 ? (
            <p className="mt-2 text-xs text-muted-foreground">
              No study sessions yet — log time from the focus timer or the planner to fill this
              chart.
            </p>
          ) : null}
          <div className="mt-4">
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={weeklyBar} margin={{ top: 4, right: 4, bottom: 0, left: -14 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="rgba(100,116,139,0.18)" />
                <XAxis
                  dataKey="day"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: '#94a3b8' }}
                  dy={8}
                />
                <YAxis
                  width={32}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: '#94a3b8' }}
                  allowDecimals={false}
                />
                <Tooltip
                  {...TOOLTIP_PROPS}
                  cursor={{ fill: 'rgba(59,130,246,0.08)' }}
                  formatter={(v) => [`${v} min`, 'Study time']}
                />
                <Bar dataKey="minutes" fill="#3b82f6" radius={[6, 6, 6, 6]} barSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <CardHeader title="Quiz performance" subtitle="Score percentage across recent quizzes." />
          {quizTrend.length === 0 ? (
            <div className="mt-4 flex flex-col items-center justify-center rounded-xl border border-dashed py-12 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-muted text-muted-foreground">
                <ListChecks className="h-5 w-5" />
              </span>
              <p className="mt-3 text-sm font-medium">Take your first quiz to see your trend</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Generate an MCQ quiz on any topic and your scores will appear here.
              </p>
              <Button size="sm" className="mt-4" onClick={() => onNavigate('quiz')}>
                Take a quiz
              </Button>
            </div>
          ) : (
            <div className="mt-4">
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={quizTrend} margin={{ top: 8, right: 8, bottom: 0, left: -14 }}>
                  <defs>
                    <linearGradient id="quizGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    vertical={false}
                    strokeDasharray="3 3"
                    stroke="rgba(100,116,139,0.18)"
                  />
                  <XAxis
                    dataKey="name"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#94a3b8' }}
                    dy={8}
                  />
                  <YAxis
                    width={32}
                    domain={[0, 100]}
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#94a3b8' }}
                  />
                  <Tooltip
                    {...TOOLTIP_PROPS}
                    cursor={{ stroke: 'rgba(139,92,246,0.35)' }}
                    formatter={(v) => [`${v}%`, 'Score']}
                  />
                  <Area
                    type="monotone"
                    dataKey="pct"
                    stroke="#8b5cf6"
                    strokeWidth={2}
                    fill="url(#quizGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </motion.section>

      {/* ----- subject-wise progress ----- */}
      <motion.section {...rise(0.15)} className="rounded-2xl border bg-card p-5 shadow-sm">
        <CardHeader title="Subject-wise progress" subtitle="Where your study time goes." />
        {subjectMinutes.length === 0 ? (
          <div className="mt-4 flex flex-col items-center justify-center rounded-xl border border-dashed py-10 text-center">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-muted text-muted-foreground">
              <Clock className="h-5 w-5" />
            </span>
            <p className="mt-3 text-sm font-medium">No study time logged by subject yet</p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Log study sessions from the Planner to see the breakdown here.
            </p>
            <Button size="sm" className="mt-4" onClick={() => onNavigate('planner')}>
              Open Planner
            </Button>
          </div>
        ) : (
          <div className="mt-4 grid gap-8 sm:grid-cols-2">
            <div className="space-y-4">
              {subjectMinutes.map((s) => (
                <div key={s.name}>
                  <div className="flex items-center gap-2.5">
                    <span
                      aria-hidden
                      className="h-2.5 w-2.5 shrink-0 rounded-full"
                      style={{ backgroundColor: s.color }}
                    />
                    <span className="min-w-0 flex-1 truncate text-sm font-medium">{s.name}</span>
                    <span className="text-xs tabular-nums text-muted-foreground">
                      {formatMinutes(s.minutes)}
                    </span>
                  </div>
                  <Progress
                    value={
                      maxSubjectMinutes > 0
                        ? Math.min(100, (s.minutes / maxSubjectMinutes) * 100)
                        : 0
                    }
                    className="mt-2 h-1.5"
                    aria-label={`${s.name} study time`}
                  />
                </div>
              ))}
            </div>
            <div>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={2}
                    strokeWidth={0}
                  >
                    {pieData.map((entry) => (
                      <Cell key={entry.name} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip {...TOOLTIP_PROPS} formatter={(v) => `${v} min`} />
                  <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </motion.section>

      {/* ----- completed assignments + quiz history ----- */}
      <motion.section {...rise(0.2)} className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <CardHeader title="Completed assignments" subtitle="Tasks you have recently finished." />
          {completedTasks.length === 0 ? (
            <div className="mt-4 flex flex-col items-center justify-center rounded-xl border border-dashed py-10 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-muted text-muted-foreground">
                <CheckCircle2 className="h-5 w-5" />
              </span>
              <p className="mt-3 text-sm font-medium">No completed tasks yet</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Finish tasks in the planner and they will show up here.
              </p>
              <Button size="sm" className="mt-4" onClick={() => onNavigate('planner')}>
                Add tasks
              </Button>
            </div>
          ) : (
            <ul className="scrollbar-thin mt-4 max-h-72 space-y-3 overflow-y-auto pr-1">
              {completedTasks.map((t) => (
                <li key={t.id} className="flex items-center gap-3">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{t.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatRelative(t.completedAt ?? t.createdAt)}
                    </p>
                  </div>
                  <Badge variant="secondary" className="max-w-24 shrink-0 truncate">
                    {t.subject}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-2xl border bg-card p-5 shadow-sm">
          <CardHeader title="Quiz history" subtitle="Your latest quiz results." />
          {quizHistory.length === 0 ? (
            <div className="mt-4 flex flex-col items-center justify-center rounded-xl border border-dashed py-10 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-muted text-muted-foreground">
                <ListChecks className="h-5 w-5" />
              </span>
              <p className="mt-3 text-sm font-medium">No quizzes yet</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Generate a quiz to start building your history.
              </p>
              <Button size="sm" className="mt-4" onClick={() => onNavigate('quiz')}>
                Take a quiz
              </Button>
            </div>
          ) : (
            <ul className="scrollbar-thin mt-4 max-h-72 space-y-3 overflow-y-auto pr-1">
              {quizHistory.map((q) => (
                <li key={q.id} className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{q.topic}</p>
                    <div className="mt-1 flex items-center gap-1.5">
                      <Badge variant="secondary" className="max-w-24 truncate">
                        {q.subject}
                      </Badge>
                      <Badge variant="secondary" className={cn('capitalize', DIFFICULTY_TINT[q.difficulty])}>
                        {q.difficulty}
                      </Badge>
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-sm font-semibold tabular-nums">
                      {q.score}/{q.total}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {Math.round((q.score / q.total) * 100)}%
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </motion.section>
    </div>
  );
}
